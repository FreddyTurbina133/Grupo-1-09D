package com.usuario.service.usuario_service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.usuario.service.usuario_service.entidades.usuario;
import com.usuario.service.usuario_service.repositorio.usuariorepositorio;
import com.usuario.service.usuario_service.servicio.usuarioservicio;

@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {

    @Mock
    private usuariorepositorio usuariorepositorio;

    @InjectMocks
    private usuarioservicio usuarioservicio;

    @Test
    void testGuardarUsuario() {
        usuario u = new usuario();
        u.setNombre("Juan");

        when(usuariorepositorio.save(u)).thenReturn(u);

        usuario resultado = usuarioservicio.save(u);
        assertEquals("Juan", resultado.getNombre());
    }

    @Test
    void testGetAllUsuarios() {
        when(usuariorepositorio.findAll()).thenReturn(List.of(new usuario(), new usuario()));
        List<usuario> resultado = usuarioservicio.getAll();
        assertEquals(2, resultado.size());
    }

    @Test
    void testGetUsuarioById() {
        usuario u = new usuario();
        u.setNombre("Maria");

        when(usuariorepositorio.findById(1)).thenReturn(Optional.of(u));
        usuario result = usuarioservicio.getUsuarioById(1);
        assertEquals("Maria", result.getNombre());
    }

    @Test
    void testEliminarUsuario() {
        doNothing().when(usuariorepositorio).deleteById(1);
        usuarioservicio.deleteUserById(1);
        verify(usuariorepositorio, times(1)).deleteById(1);
    }

    @Test
    void testGuardarUsuarioNull() {
        assertThrows(IllegalArgumentException.class, () -> usuarioservicio.save(null));
    }

    @Test
    void testGetUsuariosByRolId() {
        usuario u = new usuario();
        u.setRolId(1);

        when(usuariorepositorio.findByRolId(1)).thenReturn(List.of(u));
        List<usuario> resultado = usuarioservicio.getUsuariosByRolId(1);
        assertEquals(1, resultado.size());
        assertEquals(1, resultado.get(0).getRolId());
    }
}

