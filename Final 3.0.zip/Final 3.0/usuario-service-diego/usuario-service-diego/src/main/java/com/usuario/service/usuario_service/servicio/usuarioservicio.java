package com.usuario.service.usuario_service.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.usuario.service.usuario_service.entidades.usuario;

import com.usuario.service.usuario_service.modelo.Rol;

import com.usuario.service.usuario_service.repositorio.usuariorepositorio;

@Service
public class usuarioservicio {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private usuariorepositorio usuariorepositorio;

    public List<Rol> getProductos(int usuarioId) {
        List<Rol> rol = restTemplate.getForObject("http://localhost:8002/rol/usuario/" + usuarioId, List.class);
        return rol;
    }

    public List<usuario> getAll() {
        return usuariorepositorio.findAll();
    }

    public usuario getUsuarioById(int id) {
        return usuariorepositorio.findById(id).orElse(null);
    }

public usuario save(usuario u) {
    if (u == null) throw new IllegalArgumentException("usuario no puede ser null");
    return usuariorepositorio.save(u);
}


    public void deleteUserById(int id) {
        usuariorepositorio.deleteById(id);
    }

    // ✅ Este sí debe ir aquí
    public List<usuario> getUsuariosByRolId(int rolId) {
        return usuariorepositorio.findByRolId(rolId);
    }
    public usuario getusuarioById(int id) {
    return usuariorepositorio.findById(id).orElse(null);
    }

}
