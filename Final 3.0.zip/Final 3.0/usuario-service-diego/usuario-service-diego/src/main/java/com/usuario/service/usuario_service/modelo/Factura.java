package com.usuario.service.usuario_service.modelo;

public class Factura {
    private int id;
    private String nameProducto;
    private double total;
    // ...
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNameProducto() {
        return nameProducto;
    }
    public void setNameProducto(String nameProducto) {
        this.nameProducto = nameProducto;
    }
    public double getTotal() {
        return total;
    }
    public void setTotal(double total) {
        this.total = total;
    }
}
