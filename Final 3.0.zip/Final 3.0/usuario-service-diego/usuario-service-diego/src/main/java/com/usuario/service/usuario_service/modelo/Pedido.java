package com.usuario.service.usuario_service.modelo;

public class Pedido {
    private int id;
    private String descripcion;
    // Agrega los atributos clave que necesitas
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
