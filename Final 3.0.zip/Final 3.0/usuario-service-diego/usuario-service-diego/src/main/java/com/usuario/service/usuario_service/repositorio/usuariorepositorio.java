package com.usuario.service.usuario_service.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.usuario.service.usuario_service.entidades.usuario;

@Repository
public interface usuariorepositorio extends JpaRepository<usuario,Integer>
{
    /*
     * findAll() --> Retorna a todos los usuarios
     * findById(Integer id) --> retorna el usuario segun la id
     * save (Usuario usuario) -->Guarda el nuevo usuario
     * deleteById(Integer id)--> Elimina un usuario según su id
     */
List<usuario> findByRolId(int rolId);
}


