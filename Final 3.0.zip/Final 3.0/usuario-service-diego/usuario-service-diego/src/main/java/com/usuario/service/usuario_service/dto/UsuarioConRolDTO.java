package com.usuario.service.usuario_service.dto;

import com.usuario.service.usuario_service.entidades.usuario;
import com.usuario.service.usuario_service.modelo.Rol;

public class UsuarioConRolDTO {
    private usuario usuario;
    private Rol rol;
    
    public usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(usuario usuario) {
        this.usuario = usuario;
    }
    public Rol getRol() {
        return rol;
    }
    public void setRol(Rol rol) {
        this.rol = rol;
    }
    
}