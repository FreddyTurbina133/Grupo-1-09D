package com.usuario.service.usuario_service.Controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.usuario.service.usuario_service.dto.UsuarioConRolDTO;
import com.usuario.service.usuario_service.entidades.usuario;
import com.usuario.service.usuario_service.modelo.Rol;
import com.usuario.service.usuario_service.repositorio.usuariorepositorio;
import com.usuario.service.usuario_service.servicio.usuarioservicio;

@RestController
@RequestMapping("/usuario")
public class usuariocontrolador {
 
    @Autowired

    private usuarioservicio usuarioservicio;

    usuariocontrolador(usuariorepositorio usuariorepositorio) {
    }

    @GetMapping("/{id}")
    public ResponseEntity<usuario> obtenerUsuario(@PathVariable("id")int id){
        usuario usuario = usuarioservicio.getUsuarioById(id);
        if(usuario==null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(usuario);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<usuario> eliminarUsuario(@PathVariable("id")int id){
        usuario usuario = usuarioservicio.getUsuarioById(id);
        if(usuario==null){
            return ResponseEntity.notFound().build();
        }
        usuarioservicio.deleteUserById(id);
        return ResponseEntity.noContent().build();

    }


    @GetMapping
    public ResponseEntity<List<usuario>> listarUsuarios(){

        List<usuario> usuarios = usuarioservicio.getAll();
        if(usuarios.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(usuarios);
    }

    @PostMapping
    public ResponseEntity<usuario> guardarUsuario(@RequestBody usuario usuario){
        usuario nuevoUsuario = usuarioservicio.save(usuario);
        return ResponseEntity.ok(nuevoUsuario);
    }
    @GetMapping("/rol/{rolId}")
public ResponseEntity<List<usuario>> obtenerUsuariosPorRol(@PathVariable("rolId") int rolId) {
    List<usuario> usuarios = usuarioservicio.getUsuariosByRolId(rolId);
    if (usuarios.isEmpty()) {
        return ResponseEntity.noContent().build();
    }
    return ResponseEntity.ok(usuarios);
}

@Autowired
private RestTemplate restTemplate;

@GetMapping("/{id}/con-rol")
public ResponseEntity<UsuarioConRolDTO> obtenerUsuarioConRol(@PathVariable int id) {
    usuario usuario = usuarioservicio.getUsuarioById(id);
    if (usuario == null) {
        return ResponseEntity.notFound().build();
    }

    Rol rol = restTemplate.getForObject("http://localhost:8011/rol/" + usuario.getRolId(), Rol.class);

    UsuarioConRolDTO dto = new UsuarioConRolDTO();
    dto.setUsuario(usuario);
    dto.setRol(rol);

    return ResponseEntity.ok(dto);
}

}

