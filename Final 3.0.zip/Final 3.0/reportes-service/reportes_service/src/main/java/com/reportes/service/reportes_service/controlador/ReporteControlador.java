package com.reportes.service.reportes_service.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.reportes.service.reportes_service.entidades.Reporte;
import com.reportes.service.reportes_service.modelo.Inventario;
import com.reportes.service.reportes_service.servicio.ReporteService;

@RestController
@RequestMapping("/reporte")
public class ReporteControlador {

    @Autowired
    private ReporteService reporteService;

    // Obtener un reporte por ID
    @GetMapping("/{id}")
    public ResponseEntity<Reporte> obtenerReporte(@PathVariable("id") int id) {
        Reporte reporte = reporteService.getReporteById(id);
        if (reporte == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(reporte);
    }

    // Eliminar un reporte por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarReporte(@PathVariable("id") int id) {
        Reporte reporte = reporteService.getReporteById(id);
        if (reporte == null) {
            return ResponseEntity.notFound().build();
        }
        reporteService.deleteReporteById(id);
        return ResponseEntity.noContent().build();
    }

    // Listar todos los reportes
    @GetMapping
    public ResponseEntity<List<Reporte>> listarReportes() {
        List<Reporte> reportes = reporteService.getAll();
        if (reportes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(reportes);
    }

    // Guardar un nuevo reporte
    @PostMapping
    public ResponseEntity<Reporte> guardarReporte(@RequestBody Reporte reporte) {
        Reporte nuevoReporte = reporteService.save(reporte);
        return ResponseEntity.ok(nuevoReporte);
    }

    // Listar inventarios asociados a un reporte
    @GetMapping("/inventario/{reporteId}")
    public ResponseEntity<List<Inventario>> listarInventario(@PathVariable("reporteId") int id) {
        Reporte reporte = reporteService.getReporteById(id);
        if (reporte == null) {
            return ResponseEntity.notFound().build();
        }
        List<Inventario> inventario = reporteService.getInventarios(id);
        return ResponseEntity.ok(inventario);
    }
}

