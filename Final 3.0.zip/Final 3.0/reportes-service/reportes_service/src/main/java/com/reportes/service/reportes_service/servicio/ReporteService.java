package com.reportes.service.reportes_service.servicio;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.reportes.service.reportes_service.entidades.Reporte;
import com.reportes.service.reportes_service.modelo.Inventario;
import com.reportes.service.reportes_service.repositorio.ReporteRepository;


@Service
public class ReporteService {


    @Autowired
    private ReporteRepository reporteRepository;


    public List<Reporte> getAll(){
        return reporteRepository.findAll();
    }


    public Reporte getReporteById(int id){
        return reporteRepository.findById(id).orElse(null);
    }


    public Reporte save(Reporte reporte){
        Reporte nuevoReporte = reporteRepository.save(reporte);
        return nuevoReporte;
    }


    public void deleteReporteById(int id){
        reporteRepository.deleteById(id);
    }

    @Autowired
    private RestTemplate restTemplate;
    public List<Inventario> getInventarios(int reporteId){
        List<Inventario>inventario = restTemplate.getForObject("http://localhost:8007/inventario/reporte/"+reporteId, List.class);
        return inventario;
    }



}
