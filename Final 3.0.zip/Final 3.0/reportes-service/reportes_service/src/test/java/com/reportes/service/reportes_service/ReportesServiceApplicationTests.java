package com.reportes.service.reportes_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
