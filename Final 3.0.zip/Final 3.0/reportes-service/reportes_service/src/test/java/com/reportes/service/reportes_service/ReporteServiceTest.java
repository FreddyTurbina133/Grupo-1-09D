package com.reportes.service.reportes_service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.reportes.service.reportes_service.entidades.Reporte;
import com.reportes.service.reportes_service.repositorio.ReporteRepository;
import com.reportes.service.reportes_service.servicio.ReporteService;

public class ReporteServiceTest {

    @Mock
    private ReporteRepository reporteRepository;

    @InjectMocks
    private ReporteService reporteService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // 1. Guardar un reporte
    @Test
    public void testGuardarReporte() {
        Reporte reporte = new Reporte();
        reporte.setTipo("Error");
        reporte.setDescripcion("Falla en el sistema");
        reporte.setFecha("2025-07-05");
        reporte.setAutor("Natalia");

        when(reporteRepository.save(reporte)).thenReturn(reporte);

        Reporte resultado = reporteService.save(reporte);

        assertNotNull(resultado);
        assertEquals("Error", resultado.getTipo());
        assertEquals("Natalia", resultado.getAutor());
    }

    // 2. Buscar reporte por ID
    @Test
    public void testGetReporteById() {
        Reporte reporte = new Reporte();
        reporte.setId(1);
        reporte.setDescripcion("Detalle del reporte");

        when(reporteRepository.findById(1)).thenReturn(Optional.of(reporte));

        Reporte resultado = reporteService.getReporteById(1);

        assertNotNull(resultado);
        assertEquals("Detalle del reporte", resultado.getDescripcion());
    }

    // 3. Obtener todos los reportes
    @Test
    public void testGetAllReportes() {
        Reporte r1 = new Reporte();
        Reporte r2 = new Reporte();

        when(reporteRepository.findAll()).thenReturn(List.of(r1, r2));

        List<Reporte> lista = reporteService.getAll();

        assertEquals(2, lista.size());
    }

    // 4. Eliminar un reporte
    @Test
    public void testDeleteReporteById() {
        doNothing().when(reporteRepository).deleteById(1);

        reporteService.deleteReporteById(1);

        verify(reporteRepository, times(1)).deleteById(1);
    }

    // 5. Validar que el autor esté presente
    @Test
    public void testReporteTieneAutor() {
        Reporte reporte = new Reporte();
        reporte.setAutor("Claudio");

        assertNotNull(reporte.getAutor());
        assertEquals("Claudio", reporte.getAutor());
    }

    // 6. Validar tipo de reporte
    @Test
    public void testReporteTipoError() {
        Reporte reporte = new Reporte();
        reporte.setTipo("Error");

        assertEquals("Error", reporte.getTipo());
    }
}
