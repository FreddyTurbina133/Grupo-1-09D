package com.factura.service.factura_service.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.factura.service.factura_service.entidad.Factura;
import com.factura.service.factura_service.servicio.FacturaService;

@RestController
@RequestMapping("/factura")

public class FacturaController {

    @Autowired
    private FacturaService facturaService;

    @GetMapping
    public ResponseEntity<List<Factura>> listarFacturas(){
        List<Factura>facturas = facturaService.getAll();
        if(facturas.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(facturas);
    }


    @GetMapping("/{id}")
    public ResponseEntity<Factura> obtenerFactura(@PathVariable("id") int id){
        Factura factura = facturaService.getFacturaById(id);
        if(factura==null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(factura);
    }



    @PostMapping
    public ResponseEntity<Factura> guardarFactura(@RequestBody Factura factura){
        Factura nuevaFactura = facturaService.save(factura);
        return ResponseEntity.ok(nuevaFactura);
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity <List<Factura>> listarProductoPorUsuarioId(@PathVariable("usuarioId") int id){
        List<Factura> facturas = facturaService.byUsuarioId(id);
        if(facturas.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(facturas);
    }
}
