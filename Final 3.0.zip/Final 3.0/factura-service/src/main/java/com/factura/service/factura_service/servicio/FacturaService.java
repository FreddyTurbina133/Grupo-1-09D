package com.factura.service.factura_service.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.factura.service.factura_service.entidad.Factura;
import com.factura.service.factura_service.repositorio.FacturaRepository;


@Service
public class FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    //listar los productos
    public List<Factura> getAll(){
        return facturaRepository.findAll();
    }

    //busca un producto por su id
    public Factura getFacturaById(int id){
        return facturaRepository.findById(id).orElse(null);
    }

    public Factura save (Factura factura){
        Factura nuevaFactura = facturaRepository.save(factura);
        return nuevaFactura;        
    }

    public List<Factura> byUsuarioId(int usuarioId){
        return facturaRepository.findByUsuarioId(usuarioId);
    }

    public void deleteFacturaById(int id) {
        facturaRepository.deleteById(id);
    }

}
