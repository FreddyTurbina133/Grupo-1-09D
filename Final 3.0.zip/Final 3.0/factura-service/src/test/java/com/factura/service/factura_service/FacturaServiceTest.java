package com.factura.service.factura_service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.factura.service.factura_service.entidad.Factura;
import com.factura.service.factura_service.repositorio.FacturaRepository;
import com.factura.service.factura_service.servicio.FacturaService;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

public class FacturaServiceTest {

    @Mock
    private FacturaRepository facturaRepository;

    @InjectMocks
    private FacturaService facturaService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGuardarFactura() {
        Factura factura = new Factura();
        factura.setNameProducto("Laptop");
        factura.setTotal(119000);

        when(facturaRepository.save(any(Factura.class))).thenReturn(factura);

        Factura resultado = facturaService.save(factura);

        assertNotNull(resultado);
        assertEquals("Laptop", resultado.getNameProducto());
        assertEquals(119000, resultado.getTotal());
    }

    @Test
    public void testObtenerFacturaPorId() {
        Factura factura = new Factura();
        factura.setId(1);
        factura.setNameProducto("Mouse Gamer");

        when(facturaRepository.findById(1)).thenReturn(Optional.of(factura));

        Factura resultado = facturaService.getFacturaById(1);

        assertNotNull(resultado);
        assertEquals("Mouse Gamer", resultado.getNameProducto());
    }

    @Test
    public void testGetAllFacturas() {
        Factura f1 = new Factura();
        Factura f2 = new Factura();

        when(facturaRepository.findAll()).thenReturn(List.of(f1, f2));

        List<Factura> lista = facturaService.getAll();

        assertEquals(2, lista.size());
    }

    @Test
    public void testDeleteFactura() {
        doNothing().when(facturaRepository).deleteById(2);
        facturaService.deleteFacturaById(2);
        verify(facturaRepository, times(1)).deleteById(2);
    }

    @Test
    public void testFacturaMontoIva() {
        Factura factura = new Factura();
        factura.setMonto(50000);
        factura.setIva(9500);

        assertEquals(9500, factura.getIva());
    }

    @Test
    public void testFacturaRutCliente() {
        Factura factura = new Factura();
        factura.setRutCliente("11.111.111-1");
        assertEquals("11.111.111-1", factura.getRutCliente());
    }
}