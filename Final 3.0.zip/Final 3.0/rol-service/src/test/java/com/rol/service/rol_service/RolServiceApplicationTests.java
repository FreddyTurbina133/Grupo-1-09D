package com.rol.service.rol_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RolServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
