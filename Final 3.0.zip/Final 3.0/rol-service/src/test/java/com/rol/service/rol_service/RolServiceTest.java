package com.rol.service.rol_service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.rol.service.rol_service.entidad.Rol;
import com.rol.service.rol_service.repositorio.RolRepository;
import com.rol.service.rol_service.servicio.RolService;

@SpringBootTest
public class RolServiceTest {

    @Mock
    private RolRepository rolRepository;

    @InjectMocks
    private RolService rolService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

   @Test
    void testGuardarRol() {
        Rol r = new Rol();
        r.setNombre("Admin");  // ✅ Setear antes de hacer el mock
        when(rolRepository.save(r)).thenReturn(r);

        Rol resultado = rolService.save(r);
        assertEquals("Admin", resultado.getNombre()); // ✅ ya no es null
    }

    @Test
    void testGetAllRoles() {
        when(rolRepository.findAll()).thenReturn(List.of(new Rol(), new Rol()));
        List<Rol> resultado = rolService.getAll();
        assertEquals(2, resultado.size());
    }

    @Test
    void testGetRolById() {
        Rol r = new Rol();
        r.setNombre("User"); // ✅ Seteado correctamente

        when(rolRepository.findById(1)).thenReturn(Optional.of(r));

        Rol result = rolService.getRolById(1);
        assertEquals("User", result.getNombre());
    }

    @Test
    void testDeleteRol() {
        doNothing().when(rolRepository).deleteById(1);
        rolService.deleteById(1);
        verify(rolRepository, times(1)).deleteById(1);
    }

    @Test
    void testRolConDescripcionVacia() {
        Rol r = new Rol();
        r.setDescripcion(""); // ✅ descripción vacía, pero explícita

        when(rolRepository.save(r)).thenReturn(r);

        Rol guardado = rolService.save(r);
        assertEquals("", guardado.getDescripcion());
    }
}