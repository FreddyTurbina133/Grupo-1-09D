package com.rol.service.rol_service.controlador;

import com.rol.service.rol_service.entidad.Rol;
import com.rol.service.rol_service.modelo.Usuario;
import com.rol.service.rol_service.repositorio.RolRepository;
import com.rol.service.rol_service.servicio.RolService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;



@RestController
@RequestMapping("/rol")
public class RolController {

    private final RolRepository rolRepository;

    @Autowired
    private RolService rolService;

    public RolController(RolRepository rolRepository) {
        this.rolRepository = rolRepository;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Rol> getRolById(@PathVariable int id) {
        Rol rol = rolService.getRolById(id);
        if (rol == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(rol);
    }

    @GetMapping("/usuarios/{rolId}")
    public ResponseEntity<List<Usuario>> listarUsuariosPorRol(@PathVariable("rolId") int id) {
        Rol rol = rolService.getRolById(id);
        if (rol == null) {
            return ResponseEntity.notFound().build();
        }
        List<Usuario> usuarios = rolService.getUsuariosByRolId(id);
        return ResponseEntity.ok(usuarios);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Rol> eliminarRol(@PathVariable("id") int id) {
        Rol rol = rolService.getRolById(id);
        if (rol == null) {
            return ResponseEntity.notFound().build();
        }
        rolService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<Rol>> listarRoles() {
        List<Rol> roles = rolService.getAll();
        if (roles.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(roles);
    }

    @PostMapping
    public ResponseEntity<Rol> guardarRol(@RequestBody Rol rol) {
        Rol nuevoRol = rolService.save(rol);
        return ResponseEntity.ok(nuevoRol);
    }
}