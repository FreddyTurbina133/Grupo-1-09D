package com.rol.service.rol_service.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.rol.service.rol_service.entidad.Rol;
import com.rol.service.rol_service.modelo.Usuario;
import com.rol.service.rol_service.repositorio.RolRepository;

import java.util.stream.Collectors;


@Service
public class RolService {

    private final RestTemplate restTemplate;

    @Autowired
    private RolRepository rolRepository;

    RolService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public List<Rol> getAll() {
        return rolRepository.findAll();
    }

    public Rol getRolById(int id) {
        return rolRepository.findById(id).orElse(null);
    }

    public Rol save(Rol rol) {
        return rolRepository.save(rol);
    }

    public void deleteById(int id) {
        rolRepository.deleteById(id);
    }

    // ✅ Método para obtener todos los roles de un usuario por su ID
    public List<Rol> getRolesByid(int usuarioId) {
        return rolRepository.findAll().stream()
                .filter(rol -> rol.getId() == usuarioId)
                .collect(Collectors.toList());
    }

    public List<Usuario> getUsuariosByRolId(int rolId) {
    return restTemplate.getForObject("http://localhost:8001/usuario/rol/" + rolId, List.class);
}
    
}
