package com.rol.service.rol_service.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rol.service.rol_service.entidad.Rol;

@Repository
public interface RolRepository extends JpaRepository<Rol,Integer>
{
    /*
     * findAll() --> Retorna a todos los usuarios
     * findById(Integer id) --> retorna el usuario segun la id
     * save (Usuario usuario) -->Guarda el nuevo usuario
     * deleteById(Integer id)--> Elimina un usuario según su id
     */
     List<Rol> findByUsuarioId(int usuarioId); // Spring genera la consulta automáticamente
}

