package producto.service.producto_service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import producto.service.producto_service.Entidades.Producto;
import producto.service.producto_service.repositorio.ProductoRepository;
import producto.service.producto_service.servicio.ProductoService;

@ExtendWith(MockitoExtension.class)
public class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoService productoService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

   @Test
    public void testGuardarProducto() {
        Producto p = new Producto();
        p.setNombre("Monitor"); 

        when(productoRepository.save(p)).thenReturn(p);

        Producto resultado = productoService.save(p);

        assertEquals("Monitor", resultado.getNombre()); 
    }

    @Test
    public void testObtenerTodos() {
        when(productoRepository.findAll()).thenReturn(List.of(new Producto(), new Producto()));
        List<Producto> productos = productoService.getAll();
        assertEquals(2, productos.size());
    }

    @Test
    public void testEliminarProducto() {
        doNothing().when(productoRepository).deleteById(1);
        productoService.deleteProductoById(1);
        verify(productoRepository).deleteById(1);
    }

    @Test
    public void testBuscarPorId() {
        Producto producto = new Producto();
        producto.setProductoId(10);

        when(productoRepository.findById(10)).thenReturn(Optional.of(producto));

        Producto p = productoService.getProductoById(10);

        assertEquals(10, p.getProductoId());
    }


    @Test
    public void testNombreProducto() {
        Producto p = new Producto();
        p.setNombre("Teclado Mecánico");
        assertEquals("Teclado Mecánico", p.getNombre());
    }

    @Test
    public void testPrecioProducto() {
        Producto p = new Producto();
        p.setPrecio(29990);
        assertEquals(29990, p.getPrecio());
    }
}