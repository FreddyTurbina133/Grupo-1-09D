package producto.service.producto_service.dto;

import producto.service.producto_service.Entidades.Producto;
import producto.service.producto_service.modelo.Usuario;

public class ProductoConUsuarioDTO {
    private Producto producto;
    private Usuario usuario;

    
    public Producto getProducto() {
        return producto;
    }
    public void setProducto(Producto producto) {
        this.producto = producto;
    }
    public Usuario getUsuario() {
        return usuario;
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    // getters y setters
}
