package producto.service.producto_service.modelo;

public class Boleta {
    private int boletaId;                 // Identificador único (PK)
    private int usuarioId;          // Usuario que realizó la compra o servicio
    private String fechaEmision;    // Fecha de emisión de la boleta
    private double montoTotal;      // Monto total de la boleta
    private String detalles;        // Detalles o descripción del producto/servicio
    private String estado;          // Estado de la boleta (emitida, anulada, pagada, etc.)


    public int getBoletaId() {
        return boletaId;
    }
    public void setBoletaId(int boletaId) {
        this.boletaId = boletaId;
    }
    public int getUsuarioId() {
        return usuarioId;
    }
    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
    public String getFechaEmision() {
        return fechaEmision;
    }
    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }
    public double getMontoTotal() {
        return montoTotal;
    }
    public void setMontoTotal(double montoTotal) {
        this.montoTotal = montoTotal;
    }
    public String getDetalles() {
        return detalles;
    }
    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
