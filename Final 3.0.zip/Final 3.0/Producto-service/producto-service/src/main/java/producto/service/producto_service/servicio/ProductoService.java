package producto.service.producto_service.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import producto.service.producto_service.Entidades.Producto;
import producto.service.producto_service.dto.ProductoConUsuarioDTO;
import producto.service.producto_service.modelo.Usuario;
import producto.service.producto_service.repositorio.ProductoRepository;


@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Autowired
    private RestTemplate restTemplate;

    public Optional<Producto> getById(int id) {
        return productoRepository.findById(id);
    }

    public List<Producto> getAll() {
        return productoRepository.findAll();
    }

    public Producto getProductoById(int id) {
        return productoRepository.findById(id).orElse(null);
    }

    public Producto save(Producto producto) {
        return productoRepository.save(producto);
    }

    public void deleteProductoById(int id) {
        productoRepository.deleteById(id);
    }

    // Este método NO es necesario si estás haciendo relación inversa
    public List<Producto> getProductos(int usuarioId) {
        return restTemplate.getForObject("http://localhost:8002/producto/usuario/" + usuarioId, List.class);
    }

    // ✅ NUEVO: Producto con datos de Usuario (DTO)
    public ProductoConUsuarioDTO obtenerProductoConUsuario(int productoId) {
        Producto producto = productoRepository.findById(productoId).orElse(null);
        if (producto == null) {
            return null;
        }

        // Traer usuario desde el microservicio usuario
        Usuario usuario = restTemplate.getForObject(
            "http://localhost:8001/usuarios/" + producto.getUsuarioId(),
            Usuario.class
        );

        ProductoConUsuarioDTO dto = new ProductoConUsuarioDTO();
        dto.setProducto(producto);
        dto.setUsuario(usuario);

        return dto;
    }
}