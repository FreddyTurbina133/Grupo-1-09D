package producto.service.producto_service.controlador;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import producto.service.producto_service.Entidades.Producto;
import producto.service.producto_service.dto.ProductoConUsuarioDTO;
import producto.service.producto_service.repositorio.ProductoRepository;
import producto.service.producto_service.servicio.ProductoService;


@RestController
@RequestMapping("/producto")
public class ProductoControlador {

    private final ProductoRepository productoRepository;

    @Autowired
    private ProductoService productoService;

    public ProductoControlador(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }

    // ✅ GET producto por ID
    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerProducto(@PathVariable("id") int id) {
        Producto producto = productoService.getProductoById(id);
        if (producto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(producto);
    }

    // ✅ DELETE producto por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarProducto(@PathVariable("id") int id) {
        Producto producto = productoService.getProductoById(id);
        if (producto == null) {
            return ResponseEntity.notFound().build();
        }
        productoService.deleteProductoById(id);
        return ResponseEntity.noContent().build();
    }

    // ✅ GET todos los productos
    @GetMapping
    public ResponseEntity<List<Producto>> listarProductos() {
        List<Producto> productos = productoService.getAll();
        if (productos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(productos);
    }

    // ✅ POST guardar producto
    @PostMapping
    public ResponseEntity<Producto> guardarProducto(@RequestBody Producto producto) {
        Producto nuevoProducto = productoService.save(producto);
        return ResponseEntity.ok(nuevoProducto);
    }

    // ✅ GET productos por usuarioId
    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<Producto>> listarProductoPorUsuario(@PathVariable("usuarioId") int usuarioId) {
        List<Producto> productos = productoService.getProductos(usuarioId);
        return ResponseEntity.ok(productos);
    }

    // ✅ NUEVO: GET producto con datos del usuario embebido (DTO)
    @GetMapping("/{id}/con-usuario")
    public ResponseEntity<ProductoConUsuarioDTO> obtenerProductoConUsuario(@PathVariable int id) {
        ProductoConUsuarioDTO dto = productoService.obtenerProductoConUsuario(id);
        if (dto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(dto);
    }
}
