package producto.service.producto_service.modelo;

public class Factura {
    private int facturaId;                  // Identificador único (PK)
    private int usuarioId;           // Usuario que recibe la factura
    private String fechaEmision;     // Fecha de emisión
    private double montoTotal;       // Total a pagar
    private String razonSocial;      // Nombre o razón social del emisor
    private String direccion;        // Dirección fiscal del emisor
    private String estado;           // Estado de la factura (emitida, pagada, anulada, etc.)

    
    public int getFacturaId() {
        return facturaId;
    }
    public void setFacturaId(int facturaId) {
        this.facturaId = facturaId;
    }
    public int getUsuarioId() {
        return usuarioId;
    }
    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
    public String getFechaEmision() {
        return fechaEmision;
    }
    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }
    public double getMontoTotal() {
        return montoTotal;
    }
    public void setMontoTotal(double montoTotal) {
        this.montoTotal = montoTotal;
    }
    public String getRazonSocial() {
        return razonSocial;
    }
    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
}
