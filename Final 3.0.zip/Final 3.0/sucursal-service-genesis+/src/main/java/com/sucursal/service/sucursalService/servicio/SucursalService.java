package com.sucursal.service.sucursalService.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.sucursal.service.sucursalService.entidades.Sucursal;
import com.sucursal.service.sucursalService.repositorio.SucursalRepository;

@Service
public class SucursalService {

    @Autowired
    private SucursalRepository sucursalRepository;
    
    public List<Sucursal> getAll() {
        return sucursalRepository.findAll();
    }

    public Sucursal getSucursalById(int id) {
        return sucursalRepository.findById(id).orElse(null);
    }

    public Sucursal save(Sucursal sucursal) {
        return sucursalRepository.save(sucursal);
    }

    public void deleteById(int id) {
        sucursalRepository.deleteById(id);
    }

    // 🔍 Buscar sucursal por nombre
    public Sucursal buscarPorNombre(String nombre) {
        return sucursalRepository.findByNombre(nombre);
    }

    // ✏️ Actualizar sucursal
    public Sucursal updateSucursal(Sucursal sucursalActualizada) {
        Optional<Sucursal> existente = sucursalRepository.findById(sucursalActualizada.getId());

        if (existente.isPresent()) {
            return sucursalRepository.save(sucursalActualizada);
        } else {
            throw new IllegalArgumentException("No existe una sucursal con ID: " + sucursalActualizada.getId());
        }
    }
}
