package com.sucursal.service.sucursalService.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sucursal.service.sucursalService.entidades.Sucursal;

@Repository
public interface SucursalRepository extends JpaRepository<Sucursal,Integer>{

/*
     * findAll() --> Retorna a todos los usuarios
     * findById(Integer id) --> retorna el usuario segun la id
     * save (Usuario usuario) -->Guarda el nuevo usuario
     * deleteById(Integer id)--> Elimina un usuario según su id
     */
     Sucursal findByNombre(String nombre);

}
