package com.sucursal.service.sucursal_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SucursalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
