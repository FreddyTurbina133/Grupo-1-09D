package com.sucursal.service.sucursal_service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sucursal.service.sucursalService.entidades.Sucursal;
import com.sucursal.service.sucursalService.repositorio.SucursalRepository;
import com.sucursal.service.sucursalService.servicio.SucursalService;


public class SucursalServiceTest {

    @Mock
    private SucursalRepository sucursalRepository;

    @InjectMocks
    private SucursalService sucursalService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // 1. Obtener todas las sucursales
    @Test
    void testGetAllSucursales() {
        Sucursal s1 = new Sucursal();
        Sucursal s2 = new Sucursal();
        when(sucursalRepository.findAll()).thenReturn(List.of(s1, s2));

        List<Sucursal> resultado = sucursalService.getAll();

        assertEquals(2, resultado.size());
    }

    // 2. Buscar sucursal por ID
    @Test
    void testGetSucursalById() {
        Sucursal sucursal = new Sucursal();
        sucursal.setId(1);
        sucursal.setNombre("Sucursal Central");

        when(sucursalRepository.findById(1)).thenReturn(Optional.of(sucursal));

        Sucursal resultado = sucursalService.getSucursalById(1);

        assertNotNull(resultado);
        assertEquals("Sucursal Central", resultado.getNombre());
    }

    // 3. Guardar sucursal
    @Test
    void testSaveSucursal() {
        Sucursal s = new Sucursal();
        s.setNombre("Sucursal Norte");

        when(sucursalRepository.save(s)).thenReturn(s);

        Sucursal resultado = sucursalService.save(s);

        assertNotNull(resultado);
        assertEquals("Sucursal Norte", resultado.getNombre());
    }

    // 4. Eliminar sucursal por ID
    @Test
    void testDeleteById() {
        doNothing().when(sucursalRepository).deleteById(2);

        sucursalService.deleteById(2);

        verify(sucursalRepository, times(1)).deleteById(2);
    }

    // 5. Buscar sucursal por nombre
    @Test
    void testBuscarSucursalPorNombre() {
        Sucursal s = new Sucursal();
        s.setNombre("Sucursal Sur");

        when(sucursalRepository.findByNombre("Sucursal Sur")).thenReturn(s);

        Sucursal resultado = sucursalService.buscarPorNombre("Sucursal Sur");

        assertNotNull(resultado);
        assertEquals("Sucursal Sur", resultado.getNombre());
    }

    // 6. Actualizar una sucursal
    @Test
    void testActualizarSucursal() {
        Sucursal original = new Sucursal();
        original.setId(3);
        original.setNombre("Antigua");

        Sucursal actualizado = new Sucursal();
        actualizado.setId(3);
        actualizado.setNombre("Actualizada");

        when(sucursalRepository.findById(3)).thenReturn(Optional.of(original));
        when(sucursalRepository.save(actualizado)).thenReturn(actualizado);

        Sucursal resultado = sucursalService.updateSucursal(actualizado);

        assertNotNull(resultado);
        assertEquals("Actualizada", resultado.getNombre());
    }
}