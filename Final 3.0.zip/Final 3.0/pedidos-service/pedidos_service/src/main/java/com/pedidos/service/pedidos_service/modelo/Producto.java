package com.pedidos.service.pedidos_service.modelo;

public class Producto {
    private int id;
    private String marca;
    private int precio;
    private String sucursalid;
    private int cantidad;
    private int usuarioId;
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public int getPrecio() {
        return precio;
    }
    public void setPrecio(int precio) {
        this.precio = precio;
    }
    public String getSucursalid() {
        return sucursalid;
    }
    public void setSucursalid(String sucursalid) {
        this.sucursalid = sucursalid;
    }
    public int getCantidad() {
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    public int getUsuarioId() {
        return usuarioId;
    }
    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

}
