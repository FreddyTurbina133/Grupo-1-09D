package com.pedidos.service.pedidos_service.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.pedidos.service.pedidos_service.entidades.Pedido;


@Repository
public interface PedidosRepository extends JpaRepository<Pedido,Integer>
{
    /*
     * findAll() --> Retorna a todos los usuarios
     * findById(Integer id) --> retorna el usuario segun la id
     * save (Usuario usuario) -->Guarda el nuevo usuario
     * deleteById(Integer id)--> Elimina un usuario según su id
     */
    List<Pedido> findByUsuarioId(int usuarioId);
    List<Pedido> findBySucursalId(int sucursalId);
}

