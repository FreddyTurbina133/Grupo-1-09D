package com.pedidos.service.pedidos_service.servicio;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pedidos.service.pedidos_service.entidades.Pedido;
import com.pedidos.service.pedidos_service.modelo.Producto;
import com.pedidos.service.pedidos_service.repositorio.PedidosRepository;



@Service
public class PedidosService {


    @Autowired
    private PedidosRepository pedidosRepository;


    public List<Pedido> getAll(){
        return pedidosRepository.findAll();
    }


    public Pedido getPedidoById(int id){
        return pedidosRepository.findById(id).orElse(null);
    }


    public Pedido save(Pedido pedido){
        Pedido nuevoPedido = pedidosRepository.save(pedido);
        return nuevoPedido;
    }


    public void deletePedidoById(int id){
        pedidosRepository.deleteById(id);
    }

     // 🔽 Método para obtener pedidos por ID de usuario
    public List<Pedido> getPedidosByUsuarioId(int usuarioId) {
        return pedidosRepository.findByUsuarioId(usuarioId);
    }

    // 🔽 Método para obtener pedidos por ID de sucursal
    public List<Pedido> getPedidosBySucursalId(int sucursalId) {
        return pedidosRepository.findBySucursalId(sucursalId);
    }

    @Autowired
    private RestTemplate restTemplate;
    public List<Producto> getProductos(int id){
        List<Producto>productos = restTemplate.getForObject("http://localhost:8002/producto/pedido/"+id, List.class);
        return productos;
    }



}

