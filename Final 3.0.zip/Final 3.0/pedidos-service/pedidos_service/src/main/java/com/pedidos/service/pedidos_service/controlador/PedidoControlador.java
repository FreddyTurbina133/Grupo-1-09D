package com.pedidos.service.pedidos_service.controlador;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pedidos.service.pedidos_service.entidades.Pedido;
import com.pedidos.service.pedidos_service.modelo.Producto;
import com.pedidos.service.pedidos_service.repositorio.PedidosRepository;
import com.pedidos.service.pedidos_service.servicio.PedidosService;


@RestController
@RequestMapping("/pedidos")
public class PedidoControlador {


    private final PedidosRepository pedidosRepository;
    @Autowired


    private PedidosService pedidosService;


    PedidoControlador(PedidosRepository pedidosRepository) {
        this.pedidosRepository = pedidosRepository;
    }


    @GetMapping("/{id}")
    public ResponseEntity<Pedido> obtenerPedido(@PathVariable("id")int id){
        Pedido pedido = pedidosService.getPedidoById(id);
        if(pedido==null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(pedido);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Pedido> eliminarPedido(@PathVariable("id")int id){
        Pedido pedido = pedidosService.getPedidoById(id);
        if(pedido==null){
            return ResponseEntity.notFound().build();
        }
        pedidosService.deletePedidoById(id);
        return ResponseEntity.noContent().build();


    }



    @GetMapping
    public ResponseEntity<List<Pedido>> listarPedidos(){


        List<Pedido> pedidos = pedidosService.getAll();
        if(pedidos.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(pedidos);
    }


    @PostMapping
    public ResponseEntity<Pedido> guardarPedido(@RequestBody Pedido pedido){
        Pedido nuevoPedido = pedidosService.save(pedido);
        return ResponseEntity.ok(nuevoPedido);
    }

    @GetMapping("/productos/{pedidoId}")
    public ResponseEntity<List<Producto>>listarProducto(@PathVariable("pedidoId")int id){
        Pedido pedido = pedidosService.getPedidoById(id);
        if(pedido==null){
            return ResponseEntity.notFound().build();
        }
        List<Producto>productos = pedidosService.getProductos(id);
        return ResponseEntity.ok(productos);
    }

}

