package com.pedidos.service.pedidos_service;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.pedidos.service.pedidos_service.entidades.Pedido;
import com.pedidos.service.pedidos_service.repositorio.PedidosRepository;
import com.pedidos.service.pedidos_service.servicio.PedidosService;

@ExtendWith(MockitoExtension.class)
public class PedidoServiceTest {

    @Mock
    private PedidosRepository pedidosRepository;

    @InjectMocks
    private PedidosService pedidoService;

    @Test
    void testGuardarPedido() {
        Pedido pedido = new Pedido();
        pedido.setUsuarioId(1);
        pedido.setTotal(5000);

        when(pedidosRepository.save(pedido)).thenReturn(pedido);

        Pedido resultado = pedidoService.save(pedido);
        assertEquals(5000, resultado.getTotal());
    }

    @Test
    void testGetById() {
        Pedido pedido = new Pedido();
        pedido.setId(1);
        pedido.setEstado("Pendiente");

        when(pedidosRepository.findById(1)).thenReturn(Optional.of(pedido));

        Pedido resultado = pedidoService.getPedidoById(1);
        assertEquals("Pendiente", resultado.getEstado());
    }

    @Test
    void testEliminarPedido() {
        doNothing().when(pedidosRepository).deleteById(1);
        pedidoService.deletePedidoById(1);
        verify(pedidosRepository, times(1)).deleteById(1);
    }

    @Test
    void testGetAllPedidos() {
        Pedido p1 = new Pedido();
        Pedido p2 = new Pedido();

        when(pedidosRepository.findAll()).thenReturn(List.of(p1, p2));

        List<Pedido> resultado = pedidoService.getAll();
        assertEquals(2, resultado.size());
    }

    @Test
    void testGetPedidosByUsuarioId() {
        Pedido pedido = new Pedido();
        pedido.setUsuarioId(5);

        when(pedidosRepository.findByUsuarioId(5)).thenReturn(List.of(pedido));

        List<Pedido> resultado = pedidoService.getPedidosByUsuarioId(5);
        assertEquals(1, resultado.size());
    }

    @Test
    void testGetPedidosBySucursalId() {
        Pedido pedido = new Pedido();
        pedido.setSucursalId(3);

        when(pedidosRepository.findBySucursalId(3)).thenReturn(List.of(pedido));

        List<Pedido> resultado = pedidoService.getPedidosBySucursalId(3);
        assertEquals(1, resultado.size());
    }
}
