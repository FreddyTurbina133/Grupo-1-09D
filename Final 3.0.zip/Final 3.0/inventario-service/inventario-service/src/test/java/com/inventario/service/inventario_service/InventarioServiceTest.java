package com.inventario.service.inventario_service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.inventario.service.inventario_service.entidades.Inventario;
import com.inventario.service.inventario_service.repositorio.InventarioRepository;
import com.inventario.service.inventario_service.servicio.InventarioService;

public class InventarioServiceTest {

    @Mock
    private InventarioRepository inventarioRepository;

    @InjectMocks
    private InventarioService inventarioService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateInventario() {
        Inventario inventario = new Inventario();
        inventario.setId(1);
        inventario.setProductoId("P001");
        inventario.setSucursalId(10);
        inventario.setCantidadDisponible(100);

        when(inventarioRepository.save(any(Inventario.class))).thenReturn(inventario);

        Inventario resultado = inventarioService.createInventario(inventario);

        assertNotNull(resultado);
        assertEquals("P001", resultado.getProductoId());
        assertEquals(10, resultado.getSucursalId());
        assertEquals(100, resultado.getCantidadDisponible());
    }

    @Test
    public void testGetAllInventarios() {
        Inventario inv1 = new Inventario();
        inv1.setId(1);
        inv1.setProductoId("P001");
        inv1.setSucursalId(10);
        inv1.setCantidadDisponible(100);

        Inventario inv2 = new Inventario();
        inv2.setId(2);
        inv2.setProductoId("P002");
        inv2.setSucursalId(11);
        inv2.setCantidadDisponible(50);

        List<Inventario> inventarios = Arrays.asList(inv1, inv2);

        when(inventarioRepository.findAll()).thenReturn(inventarios);

        List<Inventario> resultado = inventarioService.getAllInventarios();

        assertEquals(2, resultado.size());
        assertEquals("P001", resultado.get(0).getProductoId());
    }

    @Test
    public void testGetInventarioById() {
        Inventario inventario = new Inventario();
        inventario.setId(1);
        inventario.setProductoId("P001");
        inventario.setSucursalId(10);
        inventario.setCantidadDisponible(100);

        when(inventarioRepository.findById(1)).thenReturn(Optional.of(inventario));

        Inventario resultado = inventarioService.getInventarioById(1);

        assertNotNull(resultado);
        assertEquals("P001", resultado.getProductoId());
    }

    @Test
    public void testGetInventariosByProductoId() {
        Inventario inv1 = new Inventario();
        inv1.setProductoId("P001");
        Inventario inv2 = new Inventario();
        inv2.setProductoId("P002");
        List<Inventario> inventarios = Arrays.asList(inv1, inv2);

        when(inventarioRepository.findAll()).thenReturn(inventarios);

        List<Inventario> resultado = inventarioService.getInventariosByProductoId("P001");

        assertEquals(1, resultado.size());
        assertEquals("P001", resultado.get(0).getProductoId());
    }

    @Test
    public void testGetInventariosBySucursalId() {
        Inventario inv1 = new Inventario();
        inv1.setSucursalId(10);
        Inventario inv2 = new Inventario();
        inv2.setSucursalId(11);
        List<Inventario> inventarios = Arrays.asList(inv1, inv2);

        when(inventarioRepository.findAll()).thenReturn(inventarios);

        List<Inventario> resultado = inventarioService.getInventariosBySucursalId(10);

        assertEquals(1, resultado.size());
        assertEquals(10, resultado.get(0).getSucursalId());
    }

    @Test
    public void testDeleteInventarioById() {
        doNothing().when(inventarioRepository).deleteById(1);
        inventarioService.deleteInventarioById(1);
        verify(inventarioRepository, times(1)).deleteById(1);
    }
}