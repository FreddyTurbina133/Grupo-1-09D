package com.inventario.service.inventario_service.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.inventario.service.inventario_service.entidades.Inventario;
import com.inventario.service.inventario_service.modelos.Producto;
import com.inventario.service.inventario_service.repositorio.InventarioRepository;

@Service
public class InventarioService {
    @Autowired
    private InventarioRepository inventarioRepository;

    // Crear un nuevo inventario
    public Inventario createInventario(Inventario inventario) {
        return inventarioRepository.save(inventario);
    }
    // Obtener todos los inventarios
    public List<Inventario> getAllInventarios() {
        return inventarioRepository.findAll();
    }
    // Obtener inventario por ID
    public Inventario getInventarioById(int id) {
        return inventarioRepository.findById(id).orElse(null);
    }
    // Obtener inventarios por productoId
    public List<Inventario> getInventariosByProductoId(String productoId) {
        return inventarioRepository.findAll().stream()
            .filter(inventario -> inventario.getProductoId().equals(productoId))
            .toList();
    }
    // Obtener inventarios por sucursalId
    public List<Inventario> getInventariosBySucursalId(int sucursalId) {
        return inventarioRepository.findAll().stream()
            .filter(inventario -> inventario.getSucursalId() == sucursalId)
            .toList();
    }
    // Eliminar inventario por ID
    public void deleteInventarioById(int id) {
        inventarioRepository.deleteById(id);
    }

    @Autowired
    private RestTemplate restTemplate;
    public List<Producto> getProductos(int productoId){
        List<Producto>productos = restTemplate.getForObject("http://localhost:8006/producto/inventario/"+productoId, List.class);
        return productos;
    }

}
