package com.inventario.service.inventario_service.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inventario.service.inventario_service.entidades.Inventario;
import com.inventario.service.inventario_service.servicio.InventarioService;

@RestController
@RequestMapping("/inventarios")
public class InventarioController {
    @Autowired
    private InventarioService inventarioService;

    // Endpoint para crear un nuevo inventario
    @PostMapping
    public ResponseEntity<Inventario> crearInventario(@RequestBody Inventario inventario) {
        Inventario nuevoInventario = inventarioService.createInventario(inventario);
        return ResponseEntity.ok(nuevoInventario);
    }

    // Endpoint para obtener todos los inventarios
    @GetMapping
    public ResponseEntity<List<Inventario>> obtenerInventarios() {
        List<Inventario> inventarios = inventarioService.getAllInventarios();
        return ResponseEntity.ok(inventarios);
    }

    // Endpoint para obtener un inventario por ID
    @GetMapping("/{id}")
    public ResponseEntity<Inventario> obtenerInventario(@PathVariable("id") int id) {
        Inventario inventario = inventarioService.getInventarioById(id);
        if (inventario == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(inventario);
    }

    // Endpoint para obtener inventarios por productoId
    @GetMapping("/producto/{productoId}")
    public ResponseEntity<List<Inventario>> obtenerInventariosPorProducto(@PathVariable("productoId") String productoId) {
        List<Inventario> inventarios = inventarioService.getInventariosByProductoId(productoId);
        return ResponseEntity.ok(inventarios);
    }

    // Endpoint para obtener inventarios por sucursalId
    @GetMapping("/sucursal/{sucursalId}")
    public ResponseEntity<List<Inventario>> obtenerInventariosPorSucursal(@PathVariable("sucursalId") int sucursalId) {
        List<Inventario> inventarios = inventarioService.getInventariosBySucursalId(sucursalId);
        return ResponseEntity.ok(inventarios);
    }

    // Endpoint para eliminar un inventario por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarInventario(@PathVariable("id") int id) {
        Inventario inventario = inventarioService.getInventarioById(id);
        if (inventario == null) {
            return ResponseEntity.notFound().build();
        }
        inventarioService.deleteInventarioById(id);
        return ResponseEntity.noContent().build();
    }
}
