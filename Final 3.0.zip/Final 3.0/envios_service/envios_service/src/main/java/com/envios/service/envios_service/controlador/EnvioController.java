package com.envios.service.envios_service.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.envios.service.envios_service.entidades.Envios;
import com.envios.service.envios_service.modelos.Pedido;
import com.envios.service.envios_service.repository.EnviosRepository;
import com.envios.service.envios_service.servicio.EnviosService;

@RestController
@RequestMapping("/Envios")
public class EnvioController {


    private final EnviosRepository enviosRepository;
    @Autowired


    private EnviosService enviosService;


    EnvioController(EnviosRepository enviosRepository) {
        this.enviosRepository = enviosRepository;
    }


    @GetMapping("/{id}")
    public ResponseEntity<Envios> obtenerEnvios(@PathVariable("id")int id){
        Envios envios = enviosService.getEnviosById(id);
        if(envios==null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(envios);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Envios> eliminarEnvios(@PathVariable("id")int id){
        Envios envios = enviosService.getEnviosById(id);
        if(envios==null){
            return ResponseEntity.notFound().build();
        }
        enviosService.deleteEnviosById(id);
        return ResponseEntity.noContent().build();
    }



    @GetMapping
    public ResponseEntity<List<Envios>> listarUsuarios(){


        List<Envios> envios = enviosService.getAll();
        if(envios.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(envios);
    }


    @PostMapping
    public ResponseEntity<Envios> guardarUsuario(@RequestBody Envios envios){
        Envios nuevoEnvios = enviosService.save(envios);
        return ResponseEntity.ok(nuevoEnvios);
    }

    @GetMapping("/productos/{envioId}")
    public ResponseEntity<List<Pedido>>listarProducto(@PathVariable("envioId")int id){
        Envios envios = enviosService.getEnviosById(id);
        if(envios==null){
            return ResponseEntity.notFound().build();
        }
        List<Pedido>pedidos = enviosService.getnombrePedido(id);
        return ResponseEntity.ok(pedidos);
    }


}

