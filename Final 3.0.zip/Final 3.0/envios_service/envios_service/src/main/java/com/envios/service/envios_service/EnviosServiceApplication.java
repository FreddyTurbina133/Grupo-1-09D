package com.envios.service.envios_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnviosServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnviosServiceApplication.class, args);
	}

}
