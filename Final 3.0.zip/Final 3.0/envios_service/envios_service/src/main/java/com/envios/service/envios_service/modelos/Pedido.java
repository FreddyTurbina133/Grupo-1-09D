package com.envios.service.envios_service.modelos;

public class Pedido {
    private int id;
    private String nombrePedido;
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNombrePedido() {
        return nombrePedido;
    }
    public void setNombrePedido(String nombrePedido) {
        this.nombrePedido = nombrePedido;
    }

}
