package com.envios.service.envios_service.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.envios.service.envios_service.entidades.Envios;
import com.envios.service.envios_service.modelos.Pedido;
import com.envios.service.envios_service.repository.EnviosRepository;

@Service
public class EnviosService {

    @Autowired
    private EnviosRepository enviosRepository;

    @Autowired
    private RestTemplate restTemplate;

    public List<Envios> getAll() {
        return enviosRepository.findAll();
    }

    public Envios getEnviosById(int id) {
        return enviosRepository.findById(id).orElse(null);
    }

    public Envios save(Envios envios) {
        if (envios.getEnvioId() != 0) {
            // Traer la entidad existente para evitar conflictos
            Envios existing = enviosRepository.findById(envios.getEnvioId()).orElse(null);
            if (existing != null) {
                existing.setDireccionEnvio(envios.getDireccionEnvio());
                existing.setEstado(envios.getEstado());
                // Guardar la entidad gestionada
                return enviosRepository.save(existing);
            }
        }
        // Caso nuevo o si no existe, guardar directamente
        return enviosRepository.save(envios);
    }

    public void deleteEnviosById(int id) {
        enviosRepository.deleteById(id);
    }

    public List<Pedido> getPedidos(int envioId) {
        List<Pedido> pedidos = restTemplate.getForObject("http://localhost:8009/pedido/envio/" + envioId, List.class);
        return pedidos;
    }

    public List<Pedido> getnombrePedido(int id) {
        throw new UnsupportedOperationException("Unimplemented method 'getnombrePedido'");
    }

    public void delete(int id) {
        enviosRepository.deleteById(id);
    }

}

