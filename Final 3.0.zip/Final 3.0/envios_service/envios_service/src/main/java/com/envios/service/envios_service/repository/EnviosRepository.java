package com.envios.service.envios_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.envios.service.envios_service.entidades.Envios;

@Repository
public interface EnviosRepository extends JpaRepository<Envios,Integer>
{
    /*
     * findAll() --> Retorna a todos los usuarios
     * findById(Integer id) --> retorna el usuario segun la id
     * save (Usuario usuario) -->Guarda el nuevo usuario
     * deleteById(Integer id)--> Elimina un usuario según su id
     */
}
