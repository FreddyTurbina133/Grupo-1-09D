package com.envios.service.envios_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EnviosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
