package com.envios.service.envios_service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.envios.service.envios_service.entidades.Envios;
import com.envios.service.envios_service.repository.EnviosRepository;
import com.envios.service.envios_service.servicio.EnviosService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class EnviosServiceTest {

    @Mock
    private EnviosRepository enviosRepository;

    @InjectMocks
    private EnviosService enviosService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAll() {
        Envios e1 = new Envios();
        e1.setEnvioId(1);
        e1.setDireccionEnvio("Elias");
        e1.setEstado("Entregado");

        Envios e2 = new Envios();
        e2.setEnvioId(2);
        e2.setDireccionEnvio("Maria");
        e2.setEstado("Pendiente");

        when(enviosRepository.findAll()).thenReturn(Arrays.asList(e1, e2));

        List<Envios> resultado = enviosService.getAll();

        assertEquals(2, resultado.size());
        assertEquals("Maria", resultado.get(1).getDireccionEnvio());
    }

    @Test
    public void testGuardarEnvio() {
        Envios nuevo = new Envios();
        nuevo.setEnvioId(3);
        nuevo.setDireccionEnvio("Luis 123");
        nuevo.setEstado("Pendiente");

        when(enviosRepository.save(nuevo)).thenReturn(nuevo);

        Envios guardado = enviosService.save(nuevo);

        assertNotNull(guardado);
        assertEquals("Luis 123", guardado.getDireccionEnvio());
    }

    @Test
    public void testGetById() {
        Envios envio = new Envios();
        envio.setEnvioId(1);
        envio.setDireccionEnvio("Pedro");
        envio.setEstado("Entregado");

        when(enviosRepository.findById(1)).thenReturn(Optional.of(envio));

        Envios resultado = enviosService.getEnviosById(1);

        assertNotNull(resultado);
        assertEquals("Pedro", resultado.getDireccionEnvio());
    }

    @Test
    public void testEliminarEnvio() {
        doNothing().when(enviosRepository).deleteById(1);
        enviosService.delete(1);
        verify(enviosRepository, times(1)).deleteById(1);
    }

    @Test
    public void testActualizarEstado() {
        Envios envio = new Envios();
        envio.setEnvioId(1);
        envio.setEstado("Pendiente");

        envio.setEstado("Entregado");

        when(enviosRepository.save(envio)).thenReturn(envio);

        Envios actualizado = enviosService.save(envio);

        assertEquals("Entregado", actualizado.getEstado());
    }

    @Test
    public void testGuardarDireccionLarga() {
        Envios envio = new Envios();
        envio.setEnvioId(4);
        envio.setDireccionEnvio("Calle Muy Larga con Nombre de 100 Caracteres 1234567890");
        envio.setEstado("Pendiente");

        when(enviosRepository.save(envio)).thenReturn(envio);

        Envios resultado = enviosService.save(envio);

        assertTrue(resultado.getDireccionEnvio().contains("Muy Larga"));
    }
}